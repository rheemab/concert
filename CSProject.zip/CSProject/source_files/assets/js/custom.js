/* Change shopping cart sub totaal price */
$('#qty').change(function() {
    $('#subtotal-price').text('price changed');
});
